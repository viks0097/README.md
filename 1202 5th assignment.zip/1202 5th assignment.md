```python
#Import Python Libraries
import numpy as np
import scipy as sp
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
#Read csv file
df_youtube= pd.read_csv("top_1000_youtubers.csv",sep=",", encoding='ISO-8859-1')
print("done")
```

    done
    


```python
df_youtube.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>web-scraper-order</th>
      <th>web-scraper-start-url</th>
      <th>userID</th>
      <th>userID-href</th>
      <th>name</th>
      <th>uploads</th>
      <th>subscribers</th>
      <th>videoviews</th>
      <th>country</th>
      <th>...</th>
      <th>usercreated</th>
      <th>grade</th>
      <th>YouTube_Link</th>
      <th>YouTube_Link-href</th>
      <th>TwitterHandle</th>
      <th>TwitterHandle-href</th>
      <th>InstagramHandle</th>
      <th>InstagramHandle-href</th>
      <th>MonthlyEarnings</th>
      <th>YearlyEarnings</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1553043067-5148</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>PewDiePie</td>
      <td>https://socialblade.com/youtube/c/pewdiepie</td>
      <td>PewDiePie</td>
      <td>3779</td>
      <td>90210848</td>
      <td>20772365682</td>
      <td>US</td>
      <td>...</td>
      <td>Apr 29th, 2010</td>
      <td>A</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UC-lHJZR3Gqxm24_Vd...</td>
      <td>NaN</td>
      <td>https://twitter.com/pewdiepie</td>
      <td>NaN</td>
      <td>https://instagram.com/pewdiepie</td>
      <td>?66.9K - ?1.1M</td>
      <td>?802.3K - ?12.8M</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1553043063-5147</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>T-Series</td>
      <td>https://socialblade.com/youtube/c/tseriesmusic</td>
      <td>T-Series</td>
      <td>13218</td>
      <td>90194329</td>
      <td>65092058996</td>
      <td>IN</td>
      <td>...</td>
      <td>Mar 13th, 2006</td>
      <td>A++</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCq-Fj5jknLsUf-MWS...</td>
      <td>NaN</td>
      <td>https://instagram.com/tseries.official</td>
      <td>NaN</td>
      <td>https://plus.google.com/115156822320080163368</td>
      <td>?635.6K - ?10.2M</td>
      <td>?7.6M - ?122M</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1553043059-5146</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>Gaming</td>
      <td>https://socialblade.com/youtube/channel/UCOpNc...</td>
      <td>Gaming</td>
      <td>0</td>
      <td>81888222</td>
      <td>0</td>
      <td>NaN</td>
      <td>...</td>
      <td>Dec 15th, 2013</td>
      <td>D-</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCOpNcN46UbXVtpKMr...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCOpNcN46UbXVtpKMr...</td>
      <td>?0 - ?0</td>
      <td>?0 - ?0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>1553043055-5145</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>YouTube Movies</td>
      <td>https://socialblade.com/youtube/channel/UClgRk...</td>
      <td>YouTube Movies</td>
      <td>0</td>
      <td>77413743</td>
      <td>0</td>
      <td>NaN</td>
      <td>...</td>
      <td>Jun 10th, 2015</td>
      <td>D-</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UClgRkhTL3_hImCAmd...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UClgRkhTL3_hImCAmd...</td>
      <td>?0 - ?0</td>
      <td>?0 - ?0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>1553043051-5144</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>Sports</td>
      <td>https://socialblade.com/youtube/channel/UCEgdi...</td>
      <td>Sports</td>
      <td>0</td>
      <td>75622870</td>
      <td>0</td>
      <td>NaN</td>
      <td>...</td>
      <td>Dec 15th, 2013</td>
      <td>D-</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCEgdi0XIXXZ-qJOFP...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCEgdi0XIXXZ-qJOFP...</td>
      <td>?0 - ?0</td>
      <td>?0 - ?0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>1553043047-5143</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>5-Minute Crafts</td>
      <td>https://socialblade.com/youtube/channel/UC295-...</td>
      <td>5-Minute Crafts</td>
      <td>2850</td>
      <td>52039165</td>
      <td>12853732711</td>
      <td>US</td>
      <td>...</td>
      <td>Nov 15th, 2016</td>
      <td>A+</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UC295-Dw_tDNtZXFeA...</td>
      <td>NaN</td>
      <td>https://www.facebook.com/5min.crafts/</td>
      <td>NaN</td>
      <td>https://instagram.com/5.min.crafts/</td>
      <td>?124.5K - ?2M</td>
      <td>?1.5M - ?23.9M</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>1553043043-5142</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>Canal KondZilla</td>
      <td>https://socialblade.com/youtube/c/kondzilla</td>
      <td>Canal KondZilla</td>
      <td>995</td>
      <td>47785398</td>
      <td>23658901687</td>
      <td>BR</td>
      <td>...</td>
      <td>Mar 21st, 2012</td>
      <td>A+</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCffDXn7ycAzwL2LDl...</td>
      <td>NaN</td>
      <td>https://instagram.com/kondzilla</td>
      <td>NaN</td>
      <td>https://plus.google.com/110909183257361061369</td>
      <td>?120.4K - ?1.9M</td>
      <td>?1.4M - ?23.1M</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>1553043039-5141</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>SET India</td>
      <td>https://socialblade.com/youtube/c/set-india</td>
      <td>SET India</td>
      <td>29688</td>
      <td>43974122</td>
      <td>30601562478</td>
      <td>IN</td>
      <td>...</td>
      <td>Sep 20th, 2006</td>
      <td>A++</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCpEhnqL0y41EpW2Tv...</td>
      <td>NaN</td>
      <td>https://twitter.com/sonyliv</td>
      <td>NaN</td>
      <td>https://plus.google.com/109225915636771502428</td>
      <td>?318.3K - ?5.1M</td>
      <td>?3.8M - ?61.1M</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>1553043035-5140</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>Justin Bieber</td>
      <td>https://socialblade.com/youtube/c/justinbieber</td>
      <td>Justin Bieber</td>
      <td>132</td>
      <td>43878072</td>
      <td>603895308</td>
      <td>CA</td>
      <td>...</td>
      <td>Jan 15th, 2007</td>
      <td>B</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCIwFjwMjI0y7PDBVE...</td>
      <td>NaN</td>
      <td>https://instagram.com/justinbieber</td>
      <td>NaN</td>
      <td>https://plus.google.com/114501909900126662096</td>
      <td>?319 - ?5.1K</td>
      <td>?3.8K - ?61.3K</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>1553043027-5138</td>
      <td>https://socialblade.com/youtube/top/5000/mosts...</td>
      <td>Cocomelon - Nursery Rhymes</td>
      <td>https://socialblade.com/youtube/c/cocomelon</td>
      <td>Cocomelon - Nursery Rhymes</td>
      <td>408</td>
      <td>40551419</td>
      <td>22962398422</td>
      <td>US</td>
      <td>...</td>
      <td>Sep 1st, 2006</td>
      <td>A++</td>
      <td>NaN</td>
      <td>https://youtube.com/channel/UCbCmjCuTUZos6Inko...</td>
      <td>NaN</td>
      <td>https://twitter.com/abckidtv</td>
      <td>NaN</td>
      <td>https://plus.google.com/117230391529580926061</td>
      <td>?567.6K - ?9.1M</td>
      <td>?6.8M - ?109M</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 21 columns</p>
</div>




```python
# Top 1000 Youtube Channel with most no. of Sucscribers
top_1000_youtubers=df_youtube.head(1000)
```


```python
#Show graphs withint Python notebook
%matplotlib inline
```


```python
# Use regular matplotlib function to display a barplot of distribution of channels
top_1000_youtubers.groupby(['channeltype'])['userID'].count().plot(kind='bar')
```




    <AxesSubplot:xlabel='channeltype'>




    
![png](output_5_1.png)
    



```python

```
